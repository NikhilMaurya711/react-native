import React, { useContext, useState } from 'react';
import { Text, View, StyleSheet, TouchableOpacity, TextInput, Button } from 'react-native';
import { Context } from '../Context/BlogContext';
import BlogPostForm from '../Components/BlogPostFom';

const CreateScreen = ({ navigation }) => {
    
    const { addBlogPost } = useContext(Context);

    return (
        <BlogPostForm onSubmit={(title,content) =>{
            addBlogPost(title,content,() => navigation.navigate('Index'))
        }
        } />
    )
}

const style = StyleSheet.create({
    
});

export default CreateScreen;