import React, { useContext } from 'react';
import { Text, View, StyleSheet, TouchableOpacity } from 'react-native';
import { Context } from '../Context/BlogContext';
import { FontAwesome } from '@expo/vector-icons';

const ShowScreen = ({ navigation }) => {
    // const id =navigation.getParam('id');
    const { state } = useContext(Context);

    const blogPost = state.find(
        blogPost => blogPost.id === navigation.getParam('id')
    );

    return (
        <View style={style.view}>
            <View style={style.titleView}>
                <Text style={style.title}>
                    {blogPost.title}
                </Text>
            </View>
            <View style={style.contentView}>
                <Text style={style.content}>
                    {blogPost.content}
                </Text>
            </View>
        </View>
    )
}

ShowScreen.navigationOptions = ({ navigation }) => {
    return {
        headerRight: () => (

            <TouchableOpacity onPress= {()=> navigation.navigate('Edit',{id:navigation.getParam('id')})}>
                    <FontAwesome name="edit" style={style.editIcon}/>
            </TouchableOpacity>
            )
    }
    
}

const style = StyleSheet.create({
    editIcon:{
        fontSize:30,
        color :"black",
        marginRight:5
    },
    view: {
        backgroundColor: '#ffffcc',
        flex: 1
    },
    titleView: {
        borderWidth: 2,
        margin: 5,
        backgroundColor: '#ffffaa'
    },
    contentView: {
        borderWidth: 1,
        margin: 5,
        flex: 1,

    },
    title: {
        fontSize: 24,
        fontWeight: 'bold',
        alignSelf: 'center',
        margin: 5,

    },
    content: {
        fontSize: 18,
        margin: 5
    }

});

export default ShowScreen;