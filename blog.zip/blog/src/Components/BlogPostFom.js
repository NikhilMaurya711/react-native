import React , {useState} from 'react'
import { Text, StyleSheet, View, Button, TextInput } from 'react-native';

const BlogPostForm = ({onSubmit, intialValue }) => {

    const [title, setTitle] = useState(intialValue.title);
    const [content, setContent] = useState(intialValue.content);

    return (
        <View>
            <Text style={style.label}> Enter Title</Text>
            <TextInput style={style.input} value={title} onChangeText={setTitle} />
            <Text style={style.label}> Content</Text>
            <TextInput style={style.input} value={content} onChangeText={setContent} />
            <Button
                title="Save post"
                onPress={() => onSubmit(title, content)}
            />

        </View>
    )
}

BlogPostForm.defaultProps ={
    intialValue:{
        title: '' ,
        content:''
    }
}

const style = StyleSheet.create({
    label: {
        margin: 5,
        marginBottom: 1,
        fontSize: 18,
        fontWeight: 'bold',
    },
    input: {
        margin: 5,
        padding: 5,
        borderWidth: 2,
        marginBottom: 15,
        fontSize: 18
    }
});
export default BlogPostForm;