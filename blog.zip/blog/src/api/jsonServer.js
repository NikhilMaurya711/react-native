import axios from 'axios';

export default axios.create({
    baseURL : 'http://fd49b492fb1d.ngrok.io',
})